from geomulticorr.src.session import open
version = "0.0.1"
print(f"""---------
GeoMultiCorr {version}
---------""")