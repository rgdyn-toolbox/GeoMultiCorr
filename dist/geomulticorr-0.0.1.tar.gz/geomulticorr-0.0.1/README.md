# GeoMultiCorr
A python lib to study earth-surface displacements from optical images with Ames Stereo Pipeline

## GitHub repo
https://github.com/rgdyn-toolbox/GeoMultiCorr